# Vercel-Deployment

1. Neues GitHub-Repository für `edivano` anlegen und diesen Ordner hochladen.
2. In Vercel: **Add New → Project → Repository importieren**.
3. Framework wird als Next.js erkannt.
4. Unter **Settings → Environment Variables** die Werte aus `.env.example` eintragen.
5. Deploy.

## Supabase
- Neues Projekt oder eigenes Edivano-Projekt anlegen.
- `supabase/schema.sql` im SQL Editor ausführen.
- Project URL, Anon Key und Service Role Key in Vercel setzen.
- Service Role Key niemals in Browsercode oder öffentlich speichern.

## Stripe
- Produkt `Edivano Familienreiseplan` anlegen.
- Einmalpreis: 9,99 EUR.
- Stripe Price-ID (`price_...`) als `STRIPE_PRICE_ID` setzen.
- Webhook auf `https://DEINE-DOMAIN/api/stripe/webhook` anlegen.
- Event: `checkout.session.completed`.
- Signing Secret als `STRIPE_WEBHOOK_SECRET` setzen.

## OpenAI
- API-Key als `OPENAI_API_KEY` setzen.
- Standardmäßig nutzt das Projekt `gpt-5.6-luna`, um Kosten niedrig zu halten.
- Optional `OPENAI_MODEL` ändern.

## Domain
Nach abgeschlossener Marken-/Domainprüfung in Vercel unter **Settings → Domains** `edivano.de` hinzufügen und DNS beim Registrar setzen.
