# Edivano Fullstack MVP

Deploy-fähiger Next.js-MVP für den KI-Familienreiseplaner.

## Flow
1. Nutzer beantwortet 6 Schritte.
2. OpenAI erzeugt 3 kostenlose Reiseideen.
3. Nutzer klickt auf 9,99 €.
4. Stripe Checkout.
5. Stripe-Webhook markiert Reiseanfrage als bezahlt.
6. Erfolgsseite erzeugt den vollständigen Plan.
7. Plan wird in Supabase gespeichert.

## Lokal starten
```bash
npm install
cp .env.example .env.local
npm run dev
```

## Vor Livegang noch erforderlich
- echte ENV-Werte
- Stripe-Produkt/Price-ID
- Supabase-Schema ausführen
- Domain
- vollständige Markenprüfung
- finale Rechtstexte / Impressum
- Gewerbe / steuerliche Einrichtung
- Bildlizenzen bzw. eigene Bilder
- Live-Datenquellen, wenn konkrete aktuelle Preise/Verfügbarkeiten angezeigt werden sollen

## Sicherheitsprinzipien
- Stripe- und Supabase-Service-Key nur serverseitig
- keine unnötigen Kinder-Namen/Geburtsdaten
- keine erfundenen Preise/Verfügbarkeiten
- kein Reiseverkauf im MVP
